from flask import Flask, render_template, request, jsonify
from twilio.rest import Client
import random
import threading
import time

# Set your Twilio account SID and auth token
account_sid = "AC1af84181181aa308c13232ba57673bc4"
auth_token = "6dcf974c469b0ce0670d391d6924c4ff"
client = Client(account_sid, auth_token)

# Set the expiration time for the OTP (in seconds)
expiration_time = 120

app = Flask(__name__)

class OTPVerification:
    def __init__(self):
        self.otp = None
        self.verified = False  # Flag to indicate whether OTP has been verified
        self.phone_number = None
        self.timer_thread = None

    # This function sends the OTP to User
    def send_otp(self):
        if self.phone_number:
            # Generate a random 6-digit OTP
            self.otp = str(random.randint(100000, 999999))

            # Send the OTP via Twilio
            try:
                client.messages.create(
                    body=f"Your OTP is: {self.otp}",
                    from_="+15642343867",
                    to=self.phone_number
                )
                print(f"OTP sent to {self.phone_number}: {self.otp}")
                # Start the timer (2 minutes)
                self.start_timer()
                return True, "An OTP has been sent to your phone number."
            except Exception as e:
                print(f"Error sending OTP: {e}")
                return False, "Failed to send OTP. Please try again."

    # This Function start's the Timer of 2 mins
    def start_timer(self):
        self.timer_thread = threading.Thread(target=self.countdown_timer)
        self.timer_thread.start()

    # This function prints the remaining time in the Terminal
    def countdown_timer(self):
        remaining_time = expiration_time
        while remaining_time > 0 and not self.verified:
            time.sleep(1)
            remaining_time -= 1
            print(f"Time remaining: {remaining_time} seconds")
        if not self.verified:
            print("OTP expired")
            # Handle OTP expiration here

otp_verifier = OTPVerification()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/send-otp', methods=['POST'])
def send_otp():
    country_code = request.form.get('country_code')
    mobile_number = request.form.get('mobile_number')
    otp_verifier.phone_number = country_code + mobile_number
    success, message = otp_verifier.send_otp()
    return jsonify({'success': success, 'message': message})

if __name__ == "__main__":
    app.run(debug=True)
